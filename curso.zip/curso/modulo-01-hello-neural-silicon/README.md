# Módulo 1 — "Hello, Neural Silicon": Desmistificando LLMs no ESP32-S3

> **Carga horária sugerida:** 3 horas  
> **Hardware padrão:** `ESP32-S3-WROOM-1 (16MB)`  
> **Arquivos do repositório explorados:** [`TinyESP32/TinyESP32.ino`](../../TinyESP32/TinyESP32.ino), [`TinyESP32/tiny_engine.h`](../../TinyESP32/tiny_engine.h), [`TinyESP32/tiny_session.cpp`](../../TinyESP32/tiny_session.cpp), [`tools/finetune_tiny.py`](../../tools/finetune_tiny.py), [`data/custom_qa.txt`](../../data/custom_qa.txt)

---

## Objetivos de Aprendizagem

Ao concluir este módulo, o aluno será capaz de:
1. Gravar e executar um **Transformer real 100% offline** dentro de um `ESP32-S3-WROOM-1 (16MB)` sem bibliotecas externas de IA.
2. Distinguir o papel físico da **Flash (`PROGMEM` / `DROM`)**, da **SRAM interna** e da **PSRAM** durante a inferência.
3. Interpretar métricas reais no **Neural Monitor** (ativação por camada, confiança por token, tokens/s e heap livre) e via comando `/status`.
4. Diagnosticar, por meio de experimento prático de fine-tuning, **por que um modelo caractere-a-caractere é limitado** — motivando toda a evolução do restante do curso.

---

## 1. Fundamentos: O Mito da "IA Só na Nuvem"

Quando perguntamos algo a um modelo comercial, o celular apenas envia texto por HTTPS para um cluster de GPUs. Aqui fazemos o oposto: **toda a matriz de pesos, a normalização, a atenção causal e a geração letra a letra acontecem dentro do silício do Xtensa LX7**, sem internet.

Como o [`TinyESP32/TinyESP32.ino`](../../TinyESP32/TinyESP32.ino) organiza o hardware do ESP32-S3?

```mermaid
flowchart LR
    FLASH["Flash 16 MB - tiny_weights.h 381 KB e web_ui.h 9.3 KB gzip"] -->|"Leitura Zero-Copy DROM"| CPU["ESP32-S3 CPU Xtensa LX7 240 MHz"]
    SRAM["SRAM Interna - KV Cache malloc 100 KB + Buffers 5.5 KB"] <-->|"Leitura e Escrita por Token"| CPU
    CPU -->|"SSE Eventos t=s, t=l, t=d"| WIFI["Wi-Fi AP AMEBA-1.0 - 192.168.4.1"]
    CPU -->|"Dual-Serial 115200 baud"| USB["USB CDC Nativo + UART0"]
```

### Três tipos de memória que todo engenheiro de IA embarcada precisa dominar

| Memória no ESP32-S3-WROOM-1 (16MB) | Velocidade Relativa | Volátil? | Uso no Firmware Atual (`TNY2`) | Limite Prático |
| :--- | :---: | :---: | :--- | :--- |
| **Flash SPI (16 MB)** | Mais lenta (usa cache L1 I/D) | Não | Código do firmware + `TINY_BIN_U32` (`381.808` bytes) + `INDEX_HTML_GZ` | No layout padrão [`partitions.csv`](../../TinyESP32/partitions.csv), `app0` tem `1.920 KB` (`0x1E0000`) |
| **SRAM Interna (512 KB)** | Muito rápida | Sim | Pilha Wi-Fi/TCP, variáveis globais e **KV Cache** (`kc`, `vc`, `ks`, `vs` = `102.400` bytes) | ~300–350 KB livres após boot; não cabe copiar os pesos para cá junto com Wi-Fi |
| **PSRAM (`0 MB` na `N16`, `2 MB` na `N16R2`, `8 MB` na `N16R8`)** | Intermediária (SPI/OPI) | Sim | Fallback automático em `tiny_alloc_kv()` quando `ESP.getFreeHeap() < 180000u && psramFound()` | Ideal para janelas de contexto longas, não obrigatória no `TNY2` |

> **Observação importante:** No ESP32-S3, quando colocamos `PROGMEM` em [`tiny_weights.h`](../../TinyESP32/tiny_weights.h), o compilador coloca o array na seção **DROM**, que é mapeada pela MMU diretamente no espaço de endereçamento da CPU. Resultado: **0 bytes de RAM gastos para armazenar os 367 mil parâmetros**.

---

## 2. Laboratório Prático 1 — Subindo o Modelo no ESP32-S3

### Passo 1: Validar a integridade do repositório no PC
Antes de abrir a Arduino IDE, execute na raiz do projeto:

```bash
python tools/verify_port.py
```

Esse script confirma que [`tiny_weights.h`](../../TinyESP32/tiny_weights.h) bate bit a bit com o binário `TNY2`, que [`web_ui.h`](../../TinyESP32/web_ui.h) descomprime exatamente para [`web/index.html`](../../web/index.html), que a matemática em C usa apenas `float` de 32 bits (sem `double`) e roda a inferência simulada em `int8`.

### Passo 2: Configurar a Arduino IDE para `ESP32-S3-WROOM-1 (16MB)`
Abra [`TinyESP32/TinyESP32.ino`](../../TinyESP32/TinyESP32.ino) e configure em **Tools**:

1. **Board:** `ESP32S3 Dev Module`
2. **USB CDC On Boot:** `Enabled` *(essencial para o `Serial` funcionar no cabo USB nativo; veja `TINY_DUAL_SERIAL` no sketch)*
3. **USB Mode:** `Hardware CDC and JTAG`
4. **Flash Size:** `16MB (128Mb)`
5. **Flash Mode:** `QIO 80MHz` *(se houver erro de boot no Serial, mude para `DIO`)*
6. **PSRAM:**
   * Se sua placa for **N16R8** (mais comum, com 8 MB Octal): `OPI PSRAM`
   * Se sua placa for **N16R2**: `QSPI PSRAM`
   * Se sua placa for **N16** (sem PSRAM): `Disabled`
7. **Partition Scheme:** `Huge APP (3MB No OTA/1MB SPIFFS)` *(ou use o [`partitions.csv`](../../TinyESP32/partitions.csv) da pasta do sketch)*.

Clique em **Upload**. Em placas S3 com USB nativo, o cabo demora **2 a 4 segundos** para reenumerar a porta COM após o reset.

### Passo 3: Testar via Serial Monitor e via Wi-Fi (Captive Portal)

1. **No Serial Monitor (`115200 baud`):**
   * Digite `/status` e observe os números impressos por `printStatusSerial()`: dimensões (`4 layers, 96 wide, 4 heads, HID 256`), `Flash pesos: 381808 bytes`, `RAM motor` (~108 KB) e `Heap livre`.
   * Digite `/demo` para ver o streaming letra por letra no terminal.
   * Teste `/0` (determinístico) versus `/9` (criatividade alta).

2. **Na Interface Web Neon (Celular ou Notebook):**
   * Conecte-se ao Access Point Wi-Fi criado pelo ESP32: **`AMEBA-1.0`** *(definido em `AP_SSID` na linha 47 de [`TinyESP32.ino`](../../TinyESP32/TinyESP32.ino); nota: documentações mais antigas do fork citam `TINY-2.1-ESP32`, mas o firmware atual sobe como `AMEBA-1.0`)*.
   * Acesse **`http://192.168.4.1`** (ou aguarde o popup automático do Captive Portal).
   * Observe o painel **`NEURAL MONITOR`** à direita enquanto faz perguntas:
     * **`LAYER ACTIVITY`**: barras em tempo real alimentadas pelo campo `"a"` dos eventos SSE (`t: "s"` enquanto lê a pergunta e `t: "l"` a cada letra gerada).
     * **`CONFIDENCE`**: mostra `last_conf`, ou seja, a probabilidade atribuída pelo modelo à letra escolhida.
     * **`SPEED`**: velocidade medida em `letters/s` no ESP32-S3.

---

## 3. Laboratório Prático 2 — Provocando os Limites do Modelo de Letras

Agora vamos testar o pipeline de fine-tuning existente e observar onde o paradigma **char-level** quebra.

### Experimento A: Treinar um mini-dataset personalizado
Crie um arquivo temporário `data/lab01_teste.txt` com 8 frases novas de automação ou respostas longas em português (ex.: tentando responder mais de 130 caracteres, ou misturando palavras parecidas):

```text
qual a temperatura ideal da estufa? | A temperatura ideal para germinacao na estufa fica entre 24 e 28 graus Celsius com umidade controlada.
ligar ventilador da bancada | Comando recebido: acionando ventilador da bancada em velocidade media.
```

Execute o fine-tuning local em PyTorch (QAT `int8`) e abra o chat quantizado no PC antes mesmo de gravar na placa:

```bash
python tools/finetune_tiny.py --data data/lab01_teste.txt --epochs 30 --out models/lab01.bin
python tools/finetune_tiny.py --chat --model models/lab01.bin
```

### Experimento B: As 3 Dores que Todo Aluno Vai Observar

Registre o que aconteceu nos testes acima e responda às perguntas de diagnóstico:

1. **Dor 1 — Amputação de Contexto (`MAXQ = 72`, `CTX = 128`):**
   * Olhe [`tiny_engine.h`](../../TinyESP32/tiny_engine.h#L11-L16) e [`generate_brazil_dataset.py`](../../tools/generate_brazil_dataset.py#L18-L19).
   * Como cada caractere consome 1 posição da janela `CTX = 128`, a primeira resposta do Experimento A **é cortada no meio da frase**! Não sobra espaço para histórico de conversa nem para ler dados de sensores no prompt.
2. **Dor 2 — Desperdício de Capacidade com Ortografia:**
   * A rede tem apenas `367.000` parâmetros (`D=96`, `L=4`). Em vez de aprender semântica ("ligar = acionar um atuador"), ela gasta dezenas de passos prevendo sílaba por sílaba (`v-e-n-t-i-l-a-d-o-r`) e tropeça quando você altera uma única palavra (`acender` vs `ligar` vs `bota o ventilador pra girar`).
   * Repare também em `tiny_clean_question()` ([`tiny_engine.cpp`](../../TinyESP32/tiny_engine.cpp#L399-L432)): para caber em `VOCAB = 97`, o firmware precisa **arrancar todos os acentos do português** (`ç -> c`, `ã -> a`, `é -> e`).
3. **Dor 3 — Muleta em C Puro (`929` linhas de regras manuais):**
   * Abra [`TinyESP32/tiny_session.cpp`](../../TinyESP32/tiny_session.cpp#L53-L177) e veja a tabela `FOLLOWUP_RULES[]` e as funções `detect_topic()` / `tiny_session_prepare()`.
   * Por que o autor precisou escrever quase mil linhas de `strstr()` e reescrita manual em C para lembrar o nome do usuário ou continuar um assunto de primeiros socorros? **Porque o modelo de 128 letras não comporta diálogo multi-turno real na atenção.**

---

## 4. Exercícios e Desafio do Módulo

1. **Leitura de Hardware:** Conecte o ESP32-S3 via Serial, rode `/status` e anote: quantos bytes de `Heap livre` restaram após alocar o KV Cache e iniciar o Wi-Fi? Faça a conta de quantos KB sobraram na SRAM interna.
2. **Efeito da Temperatura (`pick`):** Faça a mesma pergunta (`who invented the telephone` ou uma pergunta do dataset PT-BR em [`data/custom_qa.txt`](../../data/custom_qa.txt)) usando `/0`, `/4` e `/9`. Observe como a barra `CONFIDENCE` no *Neural Monitor* oscila e por que letras sem sentido aparecem em criatividade alta.
3. **Mini-pesquisa para o próximo módulo:** Abra `TinyTransformer.forward()` em [`tools/finetune_tiny.py`](../../tools/finetune_tiny.py#L155-L196) e tente identificar quantas multiplicações de matriz (`F.linear`) acontecem para gerar **uma única letra**.

---

| Anterior | Índice | Próximo |
| :--- | :---: | :--- |
| — | [Guia do Curso](../README.md) | [Módulo 2: Anatomia do Transformer em C Puro →](../modulo-02-anatomia-transformer-c/README.md) |
