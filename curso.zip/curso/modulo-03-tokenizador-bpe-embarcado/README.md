# Módulo 3 — De Letras para Ideias: Tokenizador BPE Embarcado em Português

> **Carga horária sugerida:** 4 horas  
> **Hardware padrão:** `ESP32-S3-WROOM-1 (16MB)`  
> **Arquivos de referência do repo:** [`TinyESP32/tiny_engine.cpp`](../../TinyESP32/tiny_engine.cpp) (`tiny_clean_question`), [`tools/generate_brazil_dataset.py`](../../tools/generate_brazil_dataset.py), [`data/custom_qa.txt`](../../data/custom_qa.txt)

---

## Objetivos de Aprendizagem

Ao concluir este módulo, o aluno será capaz de:
1. Explicar a diferença entre tokenização por **caracteres**, por **palavras inteiras** e por **subpalavras (BPE - Byte-Pair Encoding)**.
2. Calcular o *trade-off* matemático entre tamanho do vocabulário (`V`), tamanho da tabela de embeddings na Flash (`V × D`) e compressão de sequência no ESP32-S3 (16MB).
3. Treinar um tokenizador BPE compacto em **português com acentuação UTF-8 preservada** (`VOCAB = 4.096`).
4. Projetar a estrutura binária do vocabulário em `PROGMEM` / Flash e o algoritmo de codificação/decodificação em C sem alocação dinâmica pesada.

---

## 1. O Problema da Tokenização em Microcontroladores

Por que não usar o mesmo tokenizador de modelos gigantes (como 32.000, 50.257 ou 128.000 tokens)?

Faça a conta para uma rede enxuta de `D = 256` em `int8`:
* Se `VOCAB = 128.000` (como Llama 3): a tabela de embeddings sozinha ocuparia `128.000 × (4 + 256) = 33,28 MB` — **mais que o dobro de toda a Flash do ESP32-S3 (16 MB)**!
* Se `VOCAB = 97` (o `TNY2` atual): ocupa só `25 KB`, mas desperdiça context length e capacidade da rede soletrando letra por letra.
* Se `VOCAB = 4.096` (subpalavras BPE treinadas em PT-BR + domínio): ocupa **`4.096 × (4 + 256) = 1.064.960` bytes (~1,01 MB na Flash)**, cabendo com enorme folga nos 16 MB do ESP32-S3!

### Comparação Direta na Prática

Veja quantos passos (`step()`) o ESP32-S3 precisa executar para processar e responder a mesma frase:

| Estratégia | Frase: `"A temperatura da sala está 29°C; ligar ventilação?"` | Nº de Tokens (`step()`) | Preserva Acentos UTF-8? |
| :--- | :--- | :---: | :---: |
| **`TNY2` Char ASCII (`97`)** | `a`,` `,`t`,`e`,`m`,`p`,... (53 chars, sem acento e sem `°`) | **53 tokens** | Não (`tiny_clean_question` achata para ASCII) |
| **BPE Genérico Inglês (`32k`)** | `"A"`, `" temp"`, `"er"`, `"atura"`, `" da"`, `" sal"`, `"a"`, `" est"`, `"á"`... | ~18–22 tokens | Parcial (quebra sílabas PT-BR) |
| **BPE Domínio PT-BR (`4.096`)** | `"A"`, `" temperatura"`, `" da"`, `" sala"`, `" está"`, `" 29"`, `"°C"`, `";"`, `" ligar"`, `" ventilação"`, `"?"` | **~11 tokens** | **Sim, nativamente!** |

> **Ganho duplo no ESP32-S3:** Com ~3,8x a 4,5x menos tokens por frase, uma janela `CTX = 256` passa a comportar o equivalente a **~950 caracteres**, e o tempo percebido para gerar uma resposta inteira cai na mesma proporção!

---

## 2. Como Funciona o BPE (Byte-Pair Encoding) em Nível de Bytes

Para que o ESP32-S3 nunca trave com um caractere desconhecido (`<unk>`) — como emojis, `°`, `ç`, `ã` ou acentos agudos — usamos **Byte-Level BPE**:

1. **Base fixa de 256 tokens de byte (`0..255`):** Qualquer texto UTF-8 válido (ou byte arbitrário) sempre pode ser representado inicialmente como uma sequência de bytes `0x00..0xFF`.
2. **Tokens Especiais de Controle (`256..263`):** Reservamos IDs fixos para estruturar prompts, sensores, chamadas de ação e fim de texto.
3. **Tabela de Fusões (*Merges*):** Durante o treino no PC sobre o corpus em português (incluindo [`data/custom_qa.txt`](../../data/custom_qa.txt) e os textos do domínio do Módulo 5), o algoritmo conta repetidamente qual par adjacente de tokens `(A, B)` aparece com mais frequência e o funde em um novo token `C` até atingir `VOCAB = 4.096`.

### Layout dos `4.096` IDs do Vocabulário `TNY3-S3`

| Faixa de IDs | Quantidade | Papel | Observação Embarcada |
| :--- | :---: | :--- | :--- |
| **`0`** | 1 | `<|pad|>` | Preenchimento de batch no PyTorch (ignorado no treino com `-100`) |
| **`1`** | 1 | `<|bos|>` | Início de sequência / sistema |
| **`2`** | 1 | `<|eos|>` | Fim de resposta (para o loop de geração no ESP32) |
| **`3`** | 1 | `<|user|>` | Marca início da fala do usuário |
| **`4`** | 1 | `<|ctx|>` | Injeta leitura atual dos sensores ou trecho recuperado pelo Micro-RAG |
| **`5`** | 1 | `<|act|>` | Marca saída estruturada de comando físico (ex.: `FAN=80;LED=BLUE`) |
| **`6`** | 1 | `<|assistant|>` | Marca início da resposta em português para o usuário |
| **`7..15`** | 9 | Reservados | Expansão futura de ferramentas sem quebrar o formato binário |
| **`16..271`** | 256 | Bytes brutos `0x00..0xFF` | Garante 100% de cobertura UTF-8 sem `<unk>` (deslocados por `+16`) |
| **`272..4095`** | 3.824 | Subpalavras fundidas (BPE) | Aprendidas automaticamente no corpus em português do projeto |

> **Dica de Engenharia:** Para evitar que espaços e quebras de linha sejam fundidos de forma caótica e para preservar números dígito a dígito (vital quando o modelo lê `29` °C ou `100%`!), aplicamos uma **pré-tokenização** simples antes das fusões: separar pontuação, isolar dígitos individuais (`"29"` → `"2"`, `"9"`) e manter o prefixo de espaço colado à palavra (`" casa"`).

---

## 3. Fluxo Embarcado: Codificação e Decodificação em C Puro

No PC (Python), usar expressões regulares é trivial. No ESP32-S3, precisamos de um algoritmo **enxuto, determinístico e sem fragmentação de heap**:

```mermaid
flowchart LR
    TXT["Texto UTF-8 do Usuário"] --> PRE["Pré-tokenizador leve em C - separa dígitos e pontuações"]
    PRE --> BYTES["Converte bytes para IDs iniciais byte + 16"]
    BYTES --> LOOP["Busca par adjacente com menor rank de merge na Flash"]
    LOOP -->|"Encontrou par válido"| MERGE["Substitui par pelo ID fundido e repete"]
    LOOP -->|"Nenhum par na tabela"| OUT["Array uint16_t tokens - máx CTX"]
```

### Por que a **Decodificação** (Token → Texto UTF-8) é quase instantânea no ESP32?

Durante a geração em streaming (SSE para o navegador ou Serial), o ESP32-S3 **não precisa rodar nenhum algoritmo BPE reverso complexo**:
* Cada token `id` (`16..4095`) aponta diretamente para um slice estático de bytes UTF-8 armazenado em `PROGMEM` (ou na partição Flash):

```c
/* Exemplo da tabela compacta gerada em tiny_vocab.h (~36 KB na Flash) */
typedef struct {
    uint16_t offset;  /* posição inicial em TINY_VOCAB_POOL */
    uint8_t  len;     /* comprimento em bytes UTF-8 (1 a 24) */
} TinyTokenSlice;

typedef struct {
    uint16_t left;    /* primeiro token do par */
    uint16_t right;   /* segundo token do par */
    uint16_t merged;  /* ID resultante (272..4095), ordenado por (left, right) */
    uint16_t rank;    /* prioridade da fusão (menor = funde primeiro) */
} TinyBpeMerge;
```

* **Decodificar 1 token gerado** = `O(1)`: ler `TINY_VOCAB_POOL + slice[tok].offset` e enviar `len` bytes pelo SSE!
* **Codificar o prompt** = `O(N²)` sobre um prompt curto (tipicamente 15 a 40 tokens) usando **busca binária** na tabela ordenada `TinyBpeMerge` (`~12` comparações para `3.824` merges) — levando **menos de 0,3 ms** no ESP32-S3!

> [!TIP]
> **Cuidado com UTF-8 em streaming:** Se o modelo gerar um caractere acentuado raro que foi quebrado em dois tokens de bytes individuais (ex.: `0xC3` seguido de `0xA3` para `ã`), acumule os bytes em um mini-buffer de 4 bytes no SSE até completar o *codepoint* UTF-8 antes de enviar o evento JSON `"t":"l"` ao navegador.

---

## 4. Laboratório Prático — Construindo e Validando Seu Tokenizador PT-BR

### Passo 1: Preparar o corpus de treinamento do tokenizador
Combine as frases em português de [`data/custom_qa.txt`](../../data/custom_qa.txt) (restaurando acentos corretos ou gerando textos acentuados) com diálogos e comandos do domínio escolhido.

### Passo 2: Script conceitual de treino BPE em Python
O aluno implementará um script `tools/train_bpe.py` (sem precisar de bibliotecas pesadas, ou validando contra `tokenizers` da Hugging Face) seguindo este fluxo:

1. Normalizar o texto em `NFC` (padrão UTF-8 canônico para `ã`, `ç`, `é`).
2. Pré-segmentar palavras preservando o espaço inicial (`" temperatura"`) e mantendo dígitos separados (`0..9`).
3. Executar `3.824` iterações de fusão BPE, gravando a lista ordenada de `(left, right, merged, rank)`.
4. Exportar um binário/header `tiny_vocab.h` contendo:
   * `TINY_VOCAB_POOL[]`: concatenação dos bytes de todos os `4.096` tokens (~24 KB).
   * `TINY_VOCAB_SLICES[4096]`: `4.096 × 4 B` (~16 KB).
   * `TINY_BPE_MERGES[3824]`: ordenado por `(left, right)` para busca binária em C (`3.824 × 8 B` ≈ ~30 KB).
   * **Total na Flash:** apenas **~70 KB** (menos de 0,5% dos 16 MB do ESP32-S3!).

### Passo 3: Teste de Paridade Bit-a-Bit (Python == C)
Seguindo a mesma filosofia de [`tools/verify_port.py`](../../tools/verify_port.py), todo aluno deve executar um teste de paridade com 50 frases contendo:
* Acentos (`ação`, `coração`, `não`, `10°C`);
* Comandos curtos (`liga o led azul 50%`);
* Texto vazio, símbolos e pontuação múltipla (`"Oi!! Tudo bem???"`).

Critério de aprovação do laboratório:
1. `decode(encode(texto)) == texto` para 100% dos casos.
2. `encode_c(texto) == encode_python(texto)` com **exatamente os mesmos IDs inteiros**.
3. Medição da **taxa de compressão** no corpus de testes: atingir pelo menos **3,5 caracteres por token** (saindo de `1,0` no `TNY2`).

---

## 5. Exercícios do Módulo

1. **Trade-off de Memória:** Calcule o tamanho da tabela de embeddings (`VOCAB × (4 + D)`) para `D = 256` comparando `VOCAB = 1.024`, `VOCAB = 4.096` e `VOCAB = 16.384`. A partir de qual tamanho o custo na Flash e o tempo do último `matvec` (projeção para logits) ficam caros demais no ESP32-S3?
2. **Por que separar dígitos (`29` → `2` `9`)?** Explique o que acontece quando um tokenizador BPE funde o número `"24"` em um único token e depois recebe na entrada um valor de sensor nunca visto antes como `"247"`.
3. **Fim do `tiny_clean_question()`:** Identifique quais linhas de [`TinyESP32/tiny_engine.cpp`](../../TinyESP32/tiny_engine.cpp#L399-L432) deixam de ser necessárias (ou precisam mudar) quando o modelo passa a aceitar UTF-8 via Byte-Level BPE.

---

| Anterior | Índice | Próximo |
| :--- | :---: | :--- |
| [← Módulo 2: Anatomia do Transformer em C Puro](../modulo-02-anatomia-transformer-c/README.md) | [Guia do Curso](../README.md) | [Módulo 4: Arquitetura Moderna TNY3-S3 →](../modulo-04-arquitetura-tny3-s3/README.md) |
